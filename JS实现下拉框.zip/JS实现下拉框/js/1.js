window.onload = function(){
	var oTable = document.getElementsByTagName("ul")[0],
		oBtn = document.getElementsByTagName("img")[0],
		oLi = document.getElementsByTagName("li"),
		oCite = document.getElementsByTagName("cite")[0],
		iNumber = 0;
	oBtn.onclick = function(event){
		event = event || window.event;
		iNumber++;
		if( (iNumber%2)==1 ){
			oTable.style.display = "block";
			oBtn.className = "changeDirect";
		}else{
			oTable.style.display = "none";
			oBtn.className = "initDirect";
		}
	}

	for(var i=0; i<oLi.length; i++){
		oLi[i].onmouseover = function(event){
			event = event || window.event;
			this.style.backgroundColor = "#666";
		}
		oLi[i].onmouseout = function(event){
			event = event || window.event;
			this.style.backgroundColor = "lightblue";
		}
		oLi[i].onclick = function(event){
			event = event || window.event;
			oCite.innerHTML = this.innerHTML;
			oTable.style.display = "none";
			oBtn.className = "initDirect";
			iNumber++;
		}
	}
}
var x = 0;
function test(){
	alert(this.x);
}
var y = {};